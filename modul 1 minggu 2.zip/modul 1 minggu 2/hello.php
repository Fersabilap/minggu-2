<html>
<head>
<title>
<?php
echo"belajar php";
?>
</title>
</head>
<body>
<?php
echo"hello world";
?>
</body>
</html>
