<?php
define ("NAMA", "Sutrisno");
define ("NILAI", 90);
echo "Nama : " . NAMA;
echo "<br>Nilai : " . NILAI;
?>